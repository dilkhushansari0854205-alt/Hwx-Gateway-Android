import crypto from 'crypto';
import { QueryDocumentSnapshot } from 'firebase-admin/firestore';
import { collections } from '../../config/firestore.ts';
import { generateDeviceToken, hashString } from '../../services/security.service.ts';
import { Device, DeviceStatus, SimCard } from '../../types/index.ts';
import { UserService } from '../users/user.service.ts';

/**
 * HWX SMS Gateway - Device Management Service
 *
 * Handles multi-device registration, Dual-SIM persistence,
 * heartbeat tracking, and strict SIM verification authorization.
 */
export class DeviceService {
  /**
   * Registers a new Android device under the authenticated user.
   * Security Requirement: Newly detected SIMs are NOT automatically verified
   * or authorized for Auto Switch fallback to prevent accidental/unauthorized transmission.
   */
  static async registerDevice(
    uid: string,
    data: {
      name: string;
      androidVersion: string;
      appVersion: string;
      sims?: Array<{
        subscriptionId: number;
        slotIndex: number;
        carrierName: string;
        phoneNumber?: string;
        displayName?: string;
      }>;
    }
  ): Promise<{ device: Device; rawDeviceToken: string }> {
    const deviceId = `dev_${crypto.randomBytes(8).toString('hex')}`;
    const { rawToken, tokenHash } = generateDeviceToken();
    const now = new Date().toISOString();

    const normalizedSims: SimCard[] = (data.sims || []).map((sim, index) => {
      const simId = `sim_${deviceId}_slot${sim.slotIndex ?? index}`;
      return {
        id: simId,
        subscriptionId: sim.subscriptionId ?? index + 1,
        slotIndex: sim.slotIndex ?? index,
        carrierName: sim.carrierName || 'Unknown Carrier',
        displayName: sim.displayName || `SIM ${sim.slotIndex + 1}`,
        phoneNumber: sim.phoneNumber || undefined,
        isVerified: false,           // Explicit verification required
        isAuthorizedFallback: false, // Fallback requires explicit user consent
        lastVerifiedAt: undefined,
        createdAt: now,
        updatedAt: now,
      };
    });

    const newDevice: Device = {
      id: deviceId,
      uid,
      name: data.name || 'Android Device',
      androidVersion: data.androidVersion || 'Android',
      appVersion: data.appVersion || '1.0.0',
      status: 'offline', // Becomes online when WebSocket connects or heartbeat is received
      deviceTokenHash: tokenHash,
      lastSeen: now,
      registeredAt: now,
      updatedAt: now,
      sims: normalizedSims,
    };

    // Store in user's subcollection
    await collections.deviceDoc(uid, deviceId).set(newDevice);

    // Save individual SIMs to subcollection
    const batch = collections.users().firestore.batch();
    for (const sim of normalizedSims) {
      const simRef = collections.simDoc(uid, deviceId, sim.id);
      batch.set(simRef, sim);
    }
    await batch.commit();

    // Store global lookup for fast device authentication without table scan
    await collections.deviceLookupDoc(deviceId).set({
      uid,
      deviceId,
      registeredAt: now,
    });

    // Increment user active devices count
    await UserService.updateActiveDevicesCount(uid, 1);

    return {
      device: newDevice,
      rawDeviceToken: rawToken, // Returned ONCE upon registration
    };
  }

  /**
   * Authenticates a device by Device ID and raw device token.
   */
  static async authenticateDevice(
    deviceId: string,
    rawToken: string
  ): Promise<{ device: Device; uid: string } | null> {
    if (!deviceId || !rawToken) return null;

    const lookupDoc = await collections.deviceLookupDoc(deviceId).get();
    if (!lookupDoc.exists) {
      return null;
    }

    const { uid } = lookupDoc.data() as { uid: string };
    const deviceDoc = await collections.deviceDoc(uid, deviceId).get();

    if (!deviceDoc.exists) {
      return null;
    }

    const device = deviceDoc.data() as Device;

    if (device.status === 'disabled') {
      return null;
    }

    // Verify token hash
    const expectedHash = hashString(rawToken);
    if (device.deviceTokenHash !== expectedHash) {
      return null;
    }

    return { device, uid };
  }

  /**
   * Lists all devices owned by a user.
   */
  static async listDevices(uid: string): Promise<Omit<Device, 'deviceTokenHash'>[]> {
    const snapshot = await collections.devices(uid).orderBy('registeredAt', 'desc').get();
    return snapshot.docs.map((doc: QueryDocumentSnapshot) => {
      const data = doc.data() as Device;
      const { deviceTokenHash: _unused, ...safeDevice } = data;
      return safeDevice;
    });
  }

  /**
   * Retrieves specific device details.
   */
  static async getDevice(uid: string, deviceId: string): Promise<Omit<Device, 'deviceTokenHash'> | null> {
    const doc = await collections.deviceDoc(uid, deviceId).get();
    if (!doc.exists) return null;
    const data = doc.data() as Device;
    const { deviceTokenHash: _unused, ...safeDevice } = data;
    return safeDevice;
  }

  /**
   * Removes a registered device and cleans up lookup index.
   */
  static async deleteDevice(uid: string, deviceId: string): Promise<boolean> {
    const docRef = collections.deviceDoc(uid, deviceId);
    const doc = await docRef.get();
    if (!doc.exists) return false;

    await docRef.delete();
    await collections.deviceLookupDoc(deviceId).delete().catch(() => {});
    await UserService.updateActiveDevicesCount(uid, -1);

    return true;
  }

  /**
   * Updates device heartbeat, battery, network, and marks device online.
   */
  static async updateHeartbeat(
    uid: string,
    deviceId: string,
    payload: {
      batteryLevel?: number;
      isCharging?: boolean;
      networkType?: string;
      ipAddress?: string;
    }
  ): Promise<void> {
    const now = new Date().toISOString();
    await collections.deviceDoc(uid, deviceId).update({
      lastSeen: now,
      status: 'online',
      batteryLevel: payload.batteryLevel ?? null,
      isCharging: payload.isCharging ?? null,
      networkType: payload.networkType ?? null,
      ipAddress: payload.ipAddress ?? null,
      updatedAt: now,
    });
  }

  /**
   * Updates device status (e.g. 'online' or 'offline').
   */
  static async setDeviceStatus(uid: string, deviceId: string, status: DeviceStatus): Promise<void> {
    await collections.deviceDoc(uid, deviceId).update({
      status,
      updatedAt: new Date().toISOString(),
    });
  }

  /**
   * Lists SIM cards associated with a device.
   */
  static async listDeviceSims(uid: string, deviceId: string): Promise<SimCard[]> {
    const snapshot = await collections.sims(uid, deviceId).get();
    return snapshot.docs.map((doc: QueryDocumentSnapshot) => doc.data() as SimCard);
  }

  /**
   * Retrieves a specific SIM on a device.
   */
  static async getDeviceSim(uid: string, deviceId: string, simId: string): Promise<SimCard | null> {
    const doc = await collections.simDoc(uid, deviceId, simId).get();
    if (!doc.exists) return null;
    return doc.data() as SimCard;
  }

  /**
   * Explicitly updates verification status, authorized fallback status, or metadata for a SIM.
   */
  static async updateSimAuthorization(
    uid: string,
    deviceId: string,
    simId: string,
    updates: {
      isVerified?: boolean;
      isAuthorizedFallback?: boolean;
      displayName?: string;
      phoneNumber?: string;
    }
  ): Promise<SimCard> {
    const simRef = collections.simDoc(uid, deviceId, simId);
    const doc = await simRef.get();
    if (!doc.exists) {
      throw new Error(`SIM '${simId}' not found on device '${deviceId}'`);
    }

    const existing = doc.data() as SimCard;
    const now = new Date().toISOString();

    const updatedData: Partial<SimCard> = {
      ...updates,
      lastVerifiedAt: updates.isVerified === true ? now : existing.lastVerifiedAt,
      updatedAt: now,
    };

    await simRef.update(updatedData);

    // Also sync the embedded sims array on the parent device document
    const allSims = await this.listDeviceSims(uid, deviceId);
    await collections.deviceDoc(uid, deviceId).update({
      sims: allSims,
      updatedAt: now,
    });

    return { ...existing, ...updatedData };
  }

  /**
   * Detects SIM changes reported by phone and revokes verification upon carrier/subId changes.
   */
  static async syncDeviceSims(
    uid: string,
    deviceId: string,
    reportedSims: Array<{
      subscriptionId: number;
      slotIndex: number;
      carrierName: string;
      phoneNumber?: string;
    }>
  ): Promise<SimCard[]> {
    const existingSims = await this.listDeviceSims(uid, deviceId);
    const now = new Date().toISOString();
    const updatedSims: SimCard[] = [];

    const batch = collections.users().firestore.batch();

    for (const sim of reportedSims) {
      const existing = existingSims.find((s) => s.slotIndex === sim.slotIndex);
      const simId = existing ? existing.id : `sim_${deviceId}_slot${sim.slotIndex}`;

      let isVerified = false;
      let isAuthorizedFallback = false;

      // If existing SIM is identical in carrier and subscription ID, preserve previous authorization
      if (existing) {
        if (existing.subscriptionId === sim.subscriptionId && existing.carrierName === sim.carrierName) {
          isVerified = existing.isVerified;
          isAuthorizedFallback = existing.isAuthorizedFallback;
        } else {
          // Carrier or hardware swapped: revoke verification immediately!
          console.warn(`[SIM Change Detected] Device ${deviceId} SIM slot ${sim.slotIndex} changed from ${existing.carrierName} to ${sim.carrierName}. Revoking verification.`);
        }
      }

      const simCard: SimCard = {
        id: simId,
        subscriptionId: sim.subscriptionId,
        slotIndex: sim.slotIndex,
        carrierName: sim.carrierName,
        phoneNumber: sim.phoneNumber || existing?.phoneNumber,
        isVerified,
        isAuthorizedFallback,
        assignedBotId: existing?.assignedBotId,
        lastVerifiedAt: isVerified ? existing?.lastVerifiedAt : undefined,
        createdAt: existing?.createdAt || now,
        updatedAt: now,
      };

      const ref = collections.simDoc(uid, deviceId, simId);
      batch.set(ref, simCard);
      updatedSims.push(simCard);
    }

    await batch.commit();

    // Update sims array on device document
    await collections.deviceDoc(uid, deviceId).update({
      sims: updatedSims,
      updatedAt: now,
    });

    return updatedSims;
  }
}
