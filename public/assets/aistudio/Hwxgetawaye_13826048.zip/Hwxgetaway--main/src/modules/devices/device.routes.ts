import { Router, Request, Response } from 'express';
import { firebaseAuth } from '../../middleware/firebaseAuth.ts';
import { deviceHeartbeatLimiter } from '../../middleware/rateLimit.ts';
import { heartbeatSchema, registerDeviceSchema, updateSimSchema } from '../../validators/index.ts';
import { DeviceService } from './device.service.ts';
import { DeviceSocketManager } from '../websocket/deviceSocket.ts';

const router = Router();

/**
 * POST /v1/devices/register
 * Registers a new Android device under the authenticated user.
 * Returns raw deviceToken once.
 */
router.post('/register', firebaseAuth(), async (req: Request, res: Response): Promise<void> => {
  const validated = registerDeviceSchema.parse(req.body);
  const result = await DeviceService.registerDevice(req.user!.uid, validated);

  res.status(201).json({
    success: true,
    data: {
      device: {
        id: result.device.id,
        name: result.device.name,
        androidVersion: result.device.androidVersion,
        appVersion: result.device.appVersion,
        status: result.device.status,
        sims: result.device.sims,
        registeredAt: result.device.registeredAt,
      },
      deviceToken: result.rawDeviceToken,
    },
    message: 'Device registered successfully. Configure this deviceToken in the Android application.',
  });
});

/**
 * GET /v1/devices
 * Lists all registered devices for the user with live connection status.
 */
router.get('/', firebaseAuth(), async (req: Request, res: Response): Promise<void> => {
  const devices = await DeviceService.listDevices(req.user!.uid);
  const socketManager = DeviceSocketManager.getInstance();

  const enriched = devices.map((d) => ({
    ...d,
    isSocketConnected: socketManager.isDeviceConnected(d.id),
  }));

  res.status(200).json({
    success: true,
    data: enriched,
  });
});

/**
 * GET /v1/devices/:deviceId
 * Retrieves details for a specific device.
 */
router.get('/:deviceId', firebaseAuth(), async (req: Request, res: Response): Promise<void> => {
  const { deviceId } = req.params;
  const device = await DeviceService.getDevice(req.user!.uid, deviceId);

  if (!device) {
    res.status(404).json({
      success: false,
      error: { code: 'DEVICE_NOT_FOUND', message: 'Device not found' },
    });
    return;
  }

  const isConnected = DeviceSocketManager.getInstance().isDeviceConnected(deviceId);

  res.status(200).json({
    success: true,
    data: {
      ...device,
      isSocketConnected: isConnected,
    },
  });
});

/**
 * DELETE /v1/devices/:deviceId
 * Unregisters and removes a device.
 */
router.delete('/:deviceId', firebaseAuth(), async (req: Request, res: Response): Promise<void> => {
  const { deviceId } = req.params;
  const deleted = await DeviceService.deleteDevice(req.user!.uid, deviceId);

  if (!deleted) {
    res.status(404).json({
      success: false,
      error: { code: 'DEVICE_NOT_FOUND', message: 'Device not found' },
    });
    return;
  }

  res.status(200).json({
    success: true,
    message: 'Device unregistered successfully',
  });
});

/**
 * POST /v1/devices/:deviceId/heartbeat
 * Heartbeat endpoint for devices communicating over HTTP.
 */
router.post(
  '/:deviceId/heartbeat',
  deviceHeartbeatLimiter,
  async (req: Request, res: Response): Promise<void> => {
    const { deviceId } = req.params;
    const validated = heartbeatSchema.parse(req.body);

    // Can be authenticated via X-Device-Token or Bearer Token
    const deviceToken = req.header('x-device-token') || req.header('authorization')?.replace('Bearer ', '');
    if (!deviceToken) {
      res.status(401).json({
        success: false,
        error: { code: 'AUTH_REQUIRED', message: 'Device token required in X-Device-Token or Bearer' },
      });
      return;
    }

    const auth = await DeviceService.authenticateDevice(deviceId, deviceToken);
    if (!auth) {
      res.status(401).json({
        success: false,
        error: { code: 'DEVICE_AUTH_FAILED', message: 'Invalid device credentials' },
      });
      return;
    }

    await DeviceService.updateHeartbeat(auth.uid, deviceId, {
      batteryLevel: validated.batteryLevel,
      isCharging: validated.isCharging,
      networkType: validated.networkType,
      ipAddress: req.ip,
    });

    res.status(200).json({
      success: true,
      data: {
        deviceId,
        status: 'online',
        timestamp: new Date().toISOString(),
      },
    });
  }
);

/**
 * GET /v1/devices/:deviceId/sims
 * Lists all SIM cards registered to this device.
 */
router.get('/:deviceId/sims', firebaseAuth(), async (req: Request, res: Response): Promise<void> => {
  const { deviceId } = req.params;
  const device = await DeviceService.getDevice(req.user!.uid, deviceId);

  if (!device) {
    res.status(404).json({
      success: false,
      error: { code: 'DEVICE_NOT_FOUND', message: 'Device not found' },
    });
    return;
  }

  const sims = await DeviceService.listDeviceSims(req.user!.uid, deviceId);

  res.status(200).json({
    success: true,
    data: sims,
  });
});

/**
 * PATCH /v1/devices/:deviceId/sims/:simId
 * Authorize or update SIM verification status and Auto Switch fallback authorization.
 */
router.patch('/:deviceId/sims/:simId', firebaseAuth(), async (req: Request, res: Response): Promise<void> => {
  const { deviceId, simId } = req.params;
  const device = await DeviceService.getDevice(req.user!.uid, deviceId);

  if (!device) {
    res.status(404).json({
      success: false,
      error: { code: 'DEVICE_NOT_FOUND', message: 'Device not found' },
    });
    return;
  }

  const validated = updateSimSchema.parse(req.body);
  const updatedSim = await DeviceService.updateSimAuthorization(req.user!.uid, deviceId, simId, validated);

  res.status(200).json({
    success: true,
    data: updatedSim,
    message: 'SIM authorization updated successfully',
  });
});

export const deviceRoutes = router;
